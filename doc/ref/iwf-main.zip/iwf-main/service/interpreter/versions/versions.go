package versions

const StartingVersionUsingGlobalVersioning = 1
const StartingVersionOptimizedUpsertSearchAttribute = 2
const StartingVersionRenamedStateApi = 3
const StartingVersionContinueAsNewOnNoStates = 4
const MaxOfAllVersions = StartingVersionContinueAsNewOnNoStates
