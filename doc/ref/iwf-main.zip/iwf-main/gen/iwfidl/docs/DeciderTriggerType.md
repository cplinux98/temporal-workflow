# DeciderTriggerType

## Enum


* `ALL_COMMAND_COMPLETED` (value: `"ALL_COMMAND_COMPLETED"`)

* `ANY_COMMAND_COMPLETED` (value: `"ANY_COMMAND_COMPLETED"`)

* `ANY_COMMAND_COMBINATION_COMPLETED` (value: `"ANY_COMMAND_COMBINATION_COMPLETED"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


