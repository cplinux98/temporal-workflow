# WaitUntilApiFailurePolicy

## Enum


* `FAIL_WORKFLOW_ON_FAILURE` (value: `"FAIL_WORKFLOW_ON_FAILURE"`)

* `PROCEED_ON_FAILURE` (value: `"PROCEED_ON_FAILURE"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


