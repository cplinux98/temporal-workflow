# StartApiFailurePolicy

## Enum


* `FAIL_WORKFLOW_ON_START_API_FAILURE` (value: `"FAIL_WORKFLOW_ON_START_API_FAILURE"`)

* `PROCEED_TO_DECIDE_ON_START_API_FAILURE` (value: `"PROCEED_TO_DECIDE_ON_START_API_FAILURE"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


