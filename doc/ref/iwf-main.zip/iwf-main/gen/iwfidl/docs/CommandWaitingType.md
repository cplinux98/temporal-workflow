# CommandWaitingType

## Enum


* `ALL_COMPLETED` (value: `"ALL_COMPLETED"`)

* `ANY_COMPLETED` (value: `"ANY_COMPLETED"`)

* `ANY_COMBINATION_COMPLETED` (value: `"ANY_COMBINATION_COMPLETED"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


