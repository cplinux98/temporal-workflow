# WorkflowIDReusePolicy

## Enum


* `ALLOW_DUPLICATE_FAILED_ONLY` (value: `"ALLOW_DUPLICATE_FAILED_ONLY"`)

* `ALLOW_DUPLICATE` (value: `"ALLOW_DUPLICATE"`)

* `REJECT_DUPLICATE` (value: `"REJECT_DUPLICATE"`)

* `TERMINATE_IF_RUNNING` (value: `"TERMINATE_IF_RUNNING"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


