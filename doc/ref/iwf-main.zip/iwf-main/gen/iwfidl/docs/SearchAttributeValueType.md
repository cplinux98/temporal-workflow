# SearchAttributeValueType

## Enum


* `KEYWORD` (value: `"KEYWORD"`)

* `TEXT` (value: `"TEXT"`)

* `DATETIME` (value: `"DATETIME"`)

* `INT` (value: `"INT"`)

* `DOUBLE` (value: `"DOUBLE"`)

* `BOOL` (value: `"BOOL"`)

* `KEYWORD_ARRAY` (value: `"KEYWORD_ARRAY"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


