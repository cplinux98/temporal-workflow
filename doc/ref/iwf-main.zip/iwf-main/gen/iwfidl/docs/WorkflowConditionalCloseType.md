# WorkflowConditionalCloseType

## Enum


* `FORCE_COMPLETE_ON_INTERNAL_CHANNEL_EMPTY` (value: `"FORCE_COMPLETE_ON_INTERNAL_CHANNEL_EMPTY"`)

* `FORCE_COMPLETE_ON_SIGNAL_CHANNEL_EMPTY` (value: `"FORCE_COMPLETE_ON_SIGNAL_CHANNEL_EMPTY"`)

* `GRACEFUL_COMPLETE_ON_ALL_CHANNELS_EMPTY` (value: `"GRACEFUL_COMPLETE_ON_ALL_CHANNELS_EMPTY"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


