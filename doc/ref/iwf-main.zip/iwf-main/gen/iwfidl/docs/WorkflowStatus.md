# WorkflowStatus

## Enum


* `RUNNING` (value: `"RUNNING"`)

* `COMPLETED` (value: `"COMPLETED"`)

* `FAILED` (value: `"FAILED"`)

* `TIMEOUT` (value: `"TIMEOUT"`)

* `TERMINATED` (value: `"TERMINATED"`)

* `CANCELED` (value: `"CANCELED"`)

* `CONTINUED_AS_NEW` (value: `"CONTINUED_AS_NEW"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


