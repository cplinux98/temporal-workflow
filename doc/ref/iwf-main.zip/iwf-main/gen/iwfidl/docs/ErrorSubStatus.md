# ErrorSubStatus

## Enum


* `UNCATEGORIZED_SUB_STATUS` (value: `"UNCATEGORIZED_SUB_STATUS"`)

* `WORKFLOW_ALREADY_STARTED_SUB_STATUS` (value: `"WORKFLOW_ALREADY_STARTED_SUB_STATUS"`)

* `WORKFLOW_NOT_EXISTS_SUB_STATUS` (value: `"WORKFLOW_NOT_EXISTS_SUB_STATUS"`)

* `WORKER_API_ERROR` (value: `"WORKER_API_ERROR"`)

* `LONG_POLL_TIME_OUT_SUB_STATUS` (value: `"LONG_POLL_TIME_OUT_SUB_STATUS"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


