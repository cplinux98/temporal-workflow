# ExecuteApiFailurePolicy

## Enum


* `FAIL_WORKFLOW_ON_EXECUTE_API_FAILURE` (value: `"FAIL_WORKFLOW_ON_EXECUTE_API_FAILURE"`)

* `PROCEED_TO_CONFIGURED_STATE` (value: `"PROCEED_TO_CONFIGURED_STATE"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


