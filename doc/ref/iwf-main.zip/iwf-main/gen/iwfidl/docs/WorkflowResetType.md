# WorkflowResetType

## Enum


* `HISTORY_EVENT_ID` (value: `"HISTORY_EVENT_ID"`)

* `BEGINNING` (value: `"BEGINNING"`)

* `HISTORY_EVENT_TIME` (value: `"HISTORY_EVENT_TIME"`)

* `STATE_ID` (value: `"STATE_ID"`)

* `STATE_EXECUTION_ID` (value: `"STATE_EXECUTION_ID"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


