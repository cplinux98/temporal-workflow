# IDReusePolicy

## Enum


* `ALLOW_IF_PREVIOUS_EXISTS_ABNORMALLY` (value: `"ALLOW_IF_PREVIOUS_EXISTS_ABNORMALLY"`)

* `ALLOW_IF_NO_RUNNING` (value: `"ALLOW_IF_NO_RUNNING"`)

* `DISALLOW_REUSE` (value: `"DISALLOW_REUSE"`)

* `ALLOW_TERMINATE_IF_RUNNING` (value: `"ALLOW_TERMINATE_IF_RUNNING"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


