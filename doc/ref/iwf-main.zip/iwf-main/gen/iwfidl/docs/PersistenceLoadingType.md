# PersistenceLoadingType

## Enum


* `ALL_WITHOUT_LOCKING` (value: `"LOAD_ALL_WITHOUT_LOCKING"`)

* `PARTIAL_WITHOUT_LOCKING` (value: `"LOAD_PARTIAL_WITHOUT_LOCKING"`)

* `PARTIAL_WITH_EXCLUSIVE_LOCK` (value: `"LOAD_PARTIAL_WITH_EXCLUSIVE_LOCK"`)

* `NONE` (value: `"LOAD_NONE"`)

* `ALL_WITH_PARTIAL_LOCK` (value: `"LOAD_ALL_WITH_PARTIAL_LOCK"`)


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


