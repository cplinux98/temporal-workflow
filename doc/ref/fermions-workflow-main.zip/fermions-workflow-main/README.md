# fermions-workflow

fermions-workflow allows you run [Serverless Workflow](https://github.com/serverlessworkflow/specification) Specification.

## License

fermions-workflow is distributed under [AGPL-3.0-only](LICENSE).
