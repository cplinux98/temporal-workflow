package setting

type Bus struct {
	Redis string
}
