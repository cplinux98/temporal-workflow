package function

import (
	"testing"
)

func TestGrpcRun(t *testing.T) {

}
