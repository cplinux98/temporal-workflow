package state

import "testing"

func Test_initializeActionDataFilter(t *testing.T) {

}
