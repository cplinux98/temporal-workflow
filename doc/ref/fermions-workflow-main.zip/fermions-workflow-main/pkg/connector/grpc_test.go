package connector

import "testing"

func TestLoad(t *testing.T) {
	Load()
}
